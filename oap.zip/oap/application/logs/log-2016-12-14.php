<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-14 14:23:43 --> Config Class Initialized
INFO - 2016-12-14 14:23:43 --> Hooks Class Initialized
DEBUG - 2016-12-14 14:23:43 --> UTF-8 Support Enabled
INFO - 2016-12-14 14:23:43 --> Utf8 Class Initialized
INFO - 2016-12-14 14:23:43 --> URI Class Initialized
DEBUG - 2016-12-14 14:23:43 --> No URI present. Default controller set.
INFO - 2016-12-14 14:23:43 --> Router Class Initialized
INFO - 2016-12-14 14:23:43 --> Output Class Initialized
INFO - 2016-12-14 14:23:43 --> Security Class Initialized
DEBUG - 2016-12-14 14:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-14 14:23:43 --> Input Class Initialized
INFO - 2016-12-14 14:23:43 --> Language Class Initialized
INFO - 2016-12-14 14:23:44 --> Loader Class Initialized
INFO - 2016-12-14 14:23:44 --> Helper loaded: url_helper
INFO - 2016-12-14 14:23:44 --> Helper loaded: file_helper
INFO - 2016-12-14 14:23:44 --> Database Driver Class Initialized
INFO - 2016-12-14 14:23:44 --> Email Class Initialized
DEBUG - 2016-12-14 14:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2016-12-14 14:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-14 14:23:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-14 14:23:44 --> Pagination Class Initialized
INFO - 2016-12-14 14:23:44 --> Model Class Initialized
INFO - 2016-12-14 14:23:44 --> Model Class Initialized
INFO - 2016-12-14 14:23:44 --> Controller Class Initialized
INFO - 2016-12-14 14:23:44 --> Model Class Initialized
INFO - 2016-12-14 14:23:44 --> Model Class Initialized
DEBUG - 2016-12-14 14:23:44 --> Email class already loaded. Second attempt ignored.
INFO - 2016-12-14 14:23:44 --> Model Class Initialized
INFO - 2016-12-14 14:23:44 --> Model Class Initialized
INFO - 2016-12-14 14:23:44 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/header.php
INFO - 2016-12-14 14:23:44 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/top-header.php
INFO - 2016-12-14 14:23:44 --> File loaded: C:\xampp\htdocs\oap\application\views\pages/featured.php
INFO - 2016-12-14 14:23:44 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/ads.php
INFO - 2016-12-14 14:23:44 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/categories.php
INFO - 2016-12-14 14:23:44 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/bads.php
INFO - 2016-12-14 14:23:44 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/top-footer.php
INFO - 2016-12-14 14:23:44 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/footer.php
INFO - 2016-12-14 14:23:44 --> File loaded: C:\xampp\htdocs\oap\application\views\_layout.php
INFO - 2016-12-14 14:23:44 --> Final output sent to browser
DEBUG - 2016-12-14 14:23:44 --> Total execution time: 0.3362
INFO - 2016-12-14 14:23:53 --> Config Class Initialized
INFO - 2016-12-14 14:23:53 --> Hooks Class Initialized
DEBUG - 2016-12-14 14:23:53 --> UTF-8 Support Enabled
INFO - 2016-12-14 14:23:53 --> Utf8 Class Initialized
INFO - 2016-12-14 14:23:53 --> URI Class Initialized
DEBUG - 2016-12-14 14:23:53 --> No URI present. Default controller set.
INFO - 2016-12-14 14:23:53 --> Router Class Initialized
INFO - 2016-12-14 14:23:53 --> Output Class Initialized
INFO - 2016-12-14 14:23:53 --> Security Class Initialized
DEBUG - 2016-12-14 14:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-14 14:23:53 --> Input Class Initialized
INFO - 2016-12-14 14:23:53 --> Language Class Initialized
INFO - 2016-12-14 14:23:53 --> Loader Class Initialized
INFO - 2016-12-14 14:23:53 --> Helper loaded: url_helper
INFO - 2016-12-14 14:23:53 --> Helper loaded: file_helper
INFO - 2016-12-14 14:23:53 --> Database Driver Class Initialized
INFO - 2016-12-14 14:23:53 --> Email Class Initialized
DEBUG - 2016-12-14 14:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2016-12-14 14:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-14 14:23:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-14 14:23:53 --> Pagination Class Initialized
INFO - 2016-12-14 14:23:53 --> Model Class Initialized
INFO - 2016-12-14 14:23:53 --> Model Class Initialized
INFO - 2016-12-14 14:23:53 --> Controller Class Initialized
INFO - 2016-12-14 14:23:53 --> Model Class Initialized
INFO - 2016-12-14 14:23:53 --> Model Class Initialized
DEBUG - 2016-12-14 14:23:53 --> Email class already loaded. Second attempt ignored.
INFO - 2016-12-14 14:23:53 --> Model Class Initialized
INFO - 2016-12-14 14:23:53 --> Model Class Initialized
INFO - 2016-12-14 14:23:53 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/header.php
INFO - 2016-12-14 14:23:53 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/top-header.php
INFO - 2016-12-14 14:23:53 --> File loaded: C:\xampp\htdocs\oap\application\views\pages/featured.php
INFO - 2016-12-14 14:23:53 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/ads.php
INFO - 2016-12-14 14:23:53 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/categories.php
INFO - 2016-12-14 14:23:53 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/bads.php
INFO - 2016-12-14 14:23:53 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/top-footer.php
INFO - 2016-12-14 14:23:53 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/footer.php
INFO - 2016-12-14 14:23:53 --> File loaded: C:\xampp\htdocs\oap\application\views\_layout.php
INFO - 2016-12-14 14:23:53 --> Final output sent to browser
DEBUG - 2016-12-14 14:23:53 --> Total execution time: 0.3590
INFO - 2016-12-14 14:23:57 --> Config Class Initialized
INFO - 2016-12-14 14:23:57 --> Config Class Initialized
INFO - 2016-12-14 14:23:57 --> Hooks Class Initialized
INFO - 2016-12-14 14:23:57 --> Hooks Class Initialized
DEBUG - 2016-12-14 14:23:57 --> UTF-8 Support Enabled
DEBUG - 2016-12-14 14:23:57 --> UTF-8 Support Enabled
INFO - 2016-12-14 14:23:57 --> Utf8 Class Initialized
INFO - 2016-12-14 14:23:57 --> Utf8 Class Initialized
INFO - 2016-12-14 14:23:57 --> URI Class Initialized
INFO - 2016-12-14 14:23:57 --> URI Class Initialized
DEBUG - 2016-12-14 14:23:57 --> No URI present. Default controller set.
DEBUG - 2016-12-14 14:23:57 --> No URI present. Default controller set.
INFO - 2016-12-14 14:23:57 --> Router Class Initialized
INFO - 2016-12-14 14:23:57 --> Router Class Initialized
INFO - 2016-12-14 14:23:57 --> Output Class Initialized
INFO - 2016-12-14 14:23:57 --> Output Class Initialized
INFO - 2016-12-14 14:23:57 --> Security Class Initialized
INFO - 2016-12-14 14:23:57 --> Security Class Initialized
DEBUG - 2016-12-14 14:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-12-14 14:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-14 14:23:57 --> Input Class Initialized
INFO - 2016-12-14 14:23:57 --> Input Class Initialized
INFO - 2016-12-14 14:23:57 --> Language Class Initialized
INFO - 2016-12-14 14:23:57 --> Language Class Initialized
INFO - 2016-12-14 14:23:57 --> Loader Class Initialized
INFO - 2016-12-14 14:23:57 --> Loader Class Initialized
INFO - 2016-12-14 14:23:57 --> Helper loaded: url_helper
INFO - 2016-12-14 14:23:57 --> Helper loaded: url_helper
INFO - 2016-12-14 14:23:57 --> Helper loaded: file_helper
INFO - 2016-12-14 14:23:57 --> Helper loaded: file_helper
INFO - 2016-12-14 14:23:57 --> Database Driver Class Initialized
INFO - 2016-12-14 14:23:57 --> Database Driver Class Initialized
INFO - 2016-12-14 14:23:57 --> Email Class Initialized
INFO - 2016-12-14 14:23:57 --> Email Class Initialized
DEBUG - 2016-12-14 14:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2016-12-14 14:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2016-12-14 14:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-14 14:23:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-14 14:23:57 --> Pagination Class Initialized
INFO - 2016-12-14 14:23:57 --> Model Class Initialized
INFO - 2016-12-14 14:23:57 --> Model Class Initialized
INFO - 2016-12-14 14:23:57 --> Controller Class Initialized
INFO - 2016-12-14 14:23:57 --> Model Class Initialized
INFO - 2016-12-14 14:23:57 --> Model Class Initialized
DEBUG - 2016-12-14 14:23:57 --> Email class already loaded. Second attempt ignored.
INFO - 2016-12-14 14:23:57 --> Model Class Initialized
INFO - 2016-12-14 14:23:57 --> Model Class Initialized
INFO - 2016-12-14 14:23:57 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/header.php
INFO - 2016-12-14 14:23:57 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/top-header.php
INFO - 2016-12-14 14:23:57 --> File loaded: C:\xampp\htdocs\oap\application\views\pages/featured.php
INFO - 2016-12-14 14:23:57 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/ads.php
INFO - 2016-12-14 14:23:57 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/categories.php
INFO - 2016-12-14 14:23:57 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/bads.php
INFO - 2016-12-14 14:23:57 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/top-footer.php
INFO - 2016-12-14 14:23:57 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/footer.php
INFO - 2016-12-14 14:23:57 --> File loaded: C:\xampp\htdocs\oap\application\views\_layout.php
INFO - 2016-12-14 14:23:57 --> Final output sent to browser
DEBUG - 2016-12-14 14:23:57 --> Total execution time: 0.5529
INFO - 2016-12-14 14:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-14 14:23:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-14 14:23:57 --> Pagination Class Initialized
INFO - 2016-12-14 14:23:57 --> Model Class Initialized
INFO - 2016-12-14 14:23:57 --> Model Class Initialized
INFO - 2016-12-14 14:23:57 --> Controller Class Initialized
INFO - 2016-12-14 14:23:57 --> Model Class Initialized
INFO - 2016-12-14 14:23:57 --> Model Class Initialized
DEBUG - 2016-12-14 14:23:57 --> Email class already loaded. Second attempt ignored.
INFO - 2016-12-14 14:23:57 --> Model Class Initialized
INFO - 2016-12-14 14:23:57 --> Model Class Initialized
INFO - 2016-12-14 14:23:57 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/header.php
INFO - 2016-12-14 14:23:57 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/top-header.php
INFO - 2016-12-14 14:23:57 --> File loaded: C:\xampp\htdocs\oap\application\views\pages/featured.php
INFO - 2016-12-14 14:23:57 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/ads.php
INFO - 2016-12-14 14:23:57 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/categories.php
INFO - 2016-12-14 14:23:57 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/bads.php
INFO - 2016-12-14 14:23:57 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/top-footer.php
INFO - 2016-12-14 14:23:57 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/footer.php
INFO - 2016-12-14 14:23:57 --> File loaded: C:\xampp\htdocs\oap\application\views\_layout.php
INFO - 2016-12-14 14:23:57 --> Final output sent to browser
DEBUG - 2016-12-14 14:23:57 --> Total execution time: 0.8030
INFO - 2016-12-14 14:23:58 --> Config Class Initialized
INFO - 2016-12-14 14:23:58 --> Hooks Class Initialized
DEBUG - 2016-12-14 14:23:58 --> UTF-8 Support Enabled
INFO - 2016-12-14 14:23:58 --> Utf8 Class Initialized
INFO - 2016-12-14 14:23:58 --> URI Class Initialized
DEBUG - 2016-12-14 14:23:58 --> No URI present. Default controller set.
INFO - 2016-12-14 14:23:58 --> Router Class Initialized
INFO - 2016-12-14 14:23:58 --> Output Class Initialized
INFO - 2016-12-14 14:23:58 --> Security Class Initialized
DEBUG - 2016-12-14 14:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-14 14:23:58 --> Input Class Initialized
INFO - 2016-12-14 14:23:58 --> Language Class Initialized
INFO - 2016-12-14 14:23:58 --> Loader Class Initialized
INFO - 2016-12-14 14:23:58 --> Helper loaded: url_helper
INFO - 2016-12-14 14:23:58 --> Helper loaded: file_helper
INFO - 2016-12-14 14:23:58 --> Database Driver Class Initialized
INFO - 2016-12-14 14:23:58 --> Email Class Initialized
DEBUG - 2016-12-14 14:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2016-12-14 14:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-14 14:23:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-14 14:23:58 --> Pagination Class Initialized
INFO - 2016-12-14 14:23:58 --> Model Class Initialized
INFO - 2016-12-14 14:23:58 --> Model Class Initialized
INFO - 2016-12-14 14:23:58 --> Controller Class Initialized
INFO - 2016-12-14 14:23:58 --> Model Class Initialized
INFO - 2016-12-14 14:23:58 --> Model Class Initialized
DEBUG - 2016-12-14 14:23:58 --> Email class already loaded. Second attempt ignored.
INFO - 2016-12-14 14:23:58 --> Model Class Initialized
INFO - 2016-12-14 14:23:58 --> Model Class Initialized
INFO - 2016-12-14 14:23:58 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/header.php
INFO - 2016-12-14 14:23:58 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/top-header.php
INFO - 2016-12-14 14:23:58 --> File loaded: C:\xampp\htdocs\oap\application\views\pages/featured.php
INFO - 2016-12-14 14:23:58 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/ads.php
INFO - 2016-12-14 14:23:58 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/categories.php
INFO - 2016-12-14 14:23:58 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/bads.php
INFO - 2016-12-14 14:23:58 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/top-footer.php
INFO - 2016-12-14 14:23:58 --> File loaded: C:\xampp\htdocs\oap\application\views\partials/footer.php
INFO - 2016-12-14 14:23:58 --> File loaded: C:\xampp\htdocs\oap\application\views\_layout.php
INFO - 2016-12-14 14:23:58 --> Final output sent to browser
DEBUG - 2016-12-14 14:23:58 --> Total execution time: 0.4474
