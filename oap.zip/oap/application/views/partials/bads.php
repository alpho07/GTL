<section class="banner card" style="margin-top: 10px; padding: 10px;">

    <div class="row col-lg-12 col-lg-offset-3">

        <a href="#">
            <div class="middle-banner banner-item icon-on-left light-blue">
                <h4>Movers</h4>
                <p>All over the country</p>
                <span class="button">Learn more</span>
                <i class="icons icon-truck-1"></i>
            </div>
        </a>
    </div>




</section>