<!-- Main Navigation -->
<nav id="main-navigation" class="main-navigation2">


    <div id="search-bar">

        <div class="col-lg-12 col-md-12 col-sm-12">
            <table id="search-bar-table">
                <tr>
                    <td class="search-column-1">
                        <p><span class="grey">Popular Searches:</span> <a href="#">accessories</a>, <a href="#">audio</a>, <a href="#">camera</a>, <a href="#">phone</a>, <a href="#">storage</a>, <a href="#">more</a></p>
                        <input type="text" placeholder="Enter your keyword">
                    </td>
                    <td class="search-column-2">
                        <p class="align-right"><a href="#">Advanced Search</a></p>
                        <select class="chosen-select-search">
                            <option>Obituaries</option>
                            <option>Caskets</option>
                            <option>Pathologists</option>
                            <option>Hospitals</option>
                            <option>All Categories</option>
                        </select>
                    </td>
                </tr>
            </table>
        </div>
        <div id="search-button">
            <input type="submit" value="">
            <i class="icons icon-search-1"></i>
        </div>
    </div>

</nav>
<!-- /Main Navigation -->

</div>

</header>
<!-- /Header -->