<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<style>
    body{
        background-image: url(http://nebula.wsimg.com/70e29e58c0ebe1e47f4f4fa8b8032f95?AccessKeyId=4D73D49C367ED3062308&disposition=0&alloworigin=1);
      
    }
</style>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // put your code here
        ?>
    </body>
</html>
